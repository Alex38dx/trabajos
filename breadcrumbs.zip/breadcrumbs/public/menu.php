<ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="refrescos.php">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                refrescos
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="helados.php">
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                helados
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="sopas.php">
                <svg class="bi"><use xlink:href="#cart"/></svg>
                sopas
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2"  href="aguas.php">
                <svg class="bi"><use xlink:href="#people"/></svg>
                aguas
              </a>
            </li>
          </ul>